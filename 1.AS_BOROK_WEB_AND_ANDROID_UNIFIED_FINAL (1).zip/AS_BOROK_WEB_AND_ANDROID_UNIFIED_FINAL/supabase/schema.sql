-- AS BOROK MUSIC PRODUCTION — SHARED WEB + ANDROID APP BACKEND
-- Run in Supabase SQL Editor.
-- Never put a service_role key in the website or Android app.

create extension if not exists pgcrypto;

create table if not exists public.site_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_site_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.site_admins where user_id = auth.uid());
$$;

create table if not exists public.site_content (
  section text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  category text not null default 'sample',
  name text not null,
  description text not null default '',
  price numeric(12,2) not null default 0,
  cover_url text not null default '',
  audio_url text not null default '',
  stock integer,
  active boolean not null default true,
  featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text not null default '',
  image_url text not null default '',
  discount_text text not null default '',
  active boolean not null default true,
  starts_at timestamptz,
  ends_at timestamptz,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.studio_slots (
  slot_date date primary key,
  status text not null default 'available' check (status in ('available','booked','closed')),
  updated_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  phone text not null,
  booking_date date not null,
  service text not null,
  message text not null default '',
  status text not null default 'pending' check (status in ('pending','confirmed','cancelled','completed')),
  advance_amount numeric(12,2) not null default 1000,
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','pending','paid','refunded')),
  created_at timestamptz not null default now()
);

create table if not exists public.customer_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  address text not null default '',
  city text not null default '',
  state text not null default '',
  pin_code text not null default '',
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  total_amount numeric(12,2) not null default 0,
  shipping_address jsonb not null default '{}'::jsonb,
  status text not null default 'pending' check (status in ('pending','paid','processing','shipped','delivered','cancelled')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','pending','paid','failed','refunded')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null default 0
);

alter table public.site_content enable row level security;
alter table public.products enable row level security;
alter table public.offers enable row level security;
alter table public.studio_slots enable row level security;
alter table public.bookings enable row level security;
alter table public.customer_profiles enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

drop policy if exists site_content_public_read on public.site_content;
create policy site_content_public_read on public.site_content for select using (true);

drop policy if exists products_public_read on public.products;
create policy products_public_read on public.products for select using (active = true);

drop policy if exists offers_public_read on public.offers;
create policy offers_public_read on public.offers for select using (
  active = true and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at >= now())
);

drop policy if exists slots_public_read on public.studio_slots;
create policy slots_public_read on public.studio_slots for select using (true);

drop policy if exists site_content_admin_write on public.site_content;
create policy site_content_admin_write on public.site_content for all to authenticated
using (public.is_site_admin()) with check (public.is_site_admin());

drop policy if exists products_admin_write on public.products;
create policy products_admin_write on public.products for all to authenticated
using (public.is_site_admin()) with check (public.is_site_admin());

drop policy if exists offers_admin_write on public.offers;
create policy offers_admin_write on public.offers for all to authenticated
using (public.is_site_admin()) with check (public.is_site_admin());

drop policy if exists slots_admin_write on public.studio_slots;
create policy slots_admin_write on public.studio_slots for all to authenticated
using (public.is_site_admin()) with check (public.is_site_admin());

drop policy if exists bookings_admin_read on public.bookings;
create policy bookings_admin_read on public.bookings for select to authenticated
using (public.is_site_admin() or user_id = auth.uid());

drop policy if exists bookings_user_insert on public.bookings;
create policy bookings_user_insert on public.bookings for insert to authenticated
with check (user_id = auth.uid());

drop policy if exists bookings_admin_update on public.bookings;
create policy bookings_admin_update on public.bookings for update to authenticated
using (public.is_site_admin()) with check (public.is_site_admin());

drop policy if exists profiles_owner_all on public.customer_profiles;
create policy profiles_owner_all on public.customer_profiles for all to authenticated
using (user_id = auth.uid() or public.is_site_admin())
with check (user_id = auth.uid() or public.is_site_admin());

drop policy if exists orders_owner_read on public.orders;
create policy orders_owner_read on public.orders for select to authenticated
using (user_id = auth.uid() or public.is_site_admin());

drop policy if exists orders_owner_insert on public.orders;
create policy orders_owner_insert on public.orders for insert to authenticated
with check (user_id = auth.uid());

drop policy if exists orders_admin_update on public.orders;
create policy orders_admin_update on public.orders for update to authenticated
using (public.is_site_admin()) with check (public.is_site_admin());

drop policy if exists items_owner_read on public.order_items;
create policy items_owner_read on public.order_items for select to authenticated
using (
  public.is_site_admin()
  or exists (select 1 from public.orders o where o.id = order_items.order_id and o.user_id = auth.uid())
);

drop policy if exists items_owner_insert on public.order_items;
create policy items_owner_insert on public.order_items for insert to authenticated
with check (
  exists (select 1 from public.orders o where o.id = order_items.order_id and o.user_id = auth.uid())
);

-- After creating your admin in Supabase Authentication > Users:
-- insert into public.site_admins(user_id) values ('YOUR-AUTH-USER-UUID');

-- Real payments must use a verified payment gateway and server-side verification.
