# AS BOROK MUSIC PRODUCTION — FINAL UNIFIED WEB + ANDROID PACKAGE

The live website was checked before packaging. It currently contains:
Special Offers, Sample Store, Instruments & Studio Equipment, Services, Studio,
Availability, Booking, About, Contact and Location.

Important: the live site still shows a trial payment state ("Secure payment gateway — to be connected")
and demo instrument listings. Real payments should not be accepted until a verified payment gateway
and server-side verification are connected.

This package provides:
- website/ : latest visual site + CMS admin/config files
- supabase/ : shared database/RLS foundation for products, offers, bookings, profiles and orders
- android/ : Android app pointing to the same live website

Setup:
1. Run supabase/schema.sql in Supabase SQL Editor.
2. Create the admin user in Supabase Authentication and add its UUID to site_admins.
3. Put the public anon key in website/config.js.
4. Deploy the whole website folder to Cloudflare Pages.
5. Open android/ in Android Studio and build an APK for demo or a signed AAB for Google Play.

Never place a Supabase service_role/secret key in browser code or the Android app.
