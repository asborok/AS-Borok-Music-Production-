# AS BOROK unified website deployment

1. Run ../supabase/schema.sql in Supabase SQL Editor.
2. Create the admin user in Supabase Authentication.
3. Add that user's UUID to public.site_admins.
4. Put the PUBLIC anon key in config.js.
5. Deploy the whole website folder to Cloudflare Pages.
6. Use admin.html for content management once the CMS wiring is enabled.
7. Connect and server-verify a real payment gateway before accepting live payments.

The website was checked before packaging and currently contains the latest visual sections:
Special Offers, Sample Store, Instruments & Studio Equipment, Services, Studio,
Availability, Booking, About, Contact and Location.
