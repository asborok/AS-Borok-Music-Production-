window.ASBOROK_CONFIG = {
  supabaseUrl: 'https://bryrvwqfxbblhbwldens.supabase.co',
  supabaseAnonKey: 'PASTE_YOUR_SUPABASE_ANON_KEY_HERE'
};
// Use only the public anon key here. Never use service_role.
