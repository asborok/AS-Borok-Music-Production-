# AS BOROK Music Production — Android app
The app opens the same live website used by the web deployment:
https://asborok.pages.dev/

It includes a branded splash screen, official-style icon, back navigation,
pull-to-refresh and offline handling.

For Play Store, build a signed Android App Bundle (.aab). APK is for demo installation.
