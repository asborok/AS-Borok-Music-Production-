package com.asborok.musicproduction

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: View
    private lateinit var offline: View
    private val homeUrl = "https://asborok.pages.dev/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.webView)
        swipe = findViewById(R.id.swipe)
        progress = findViewById(R.id.progress)
        offline = findViewById(R.id.offline)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString += " ASBOROKAndroidApp/2.0"
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val s = request.url.scheme ?: return false
                if (s == "http" || s == "https") return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, request.url)); true }
                catch (_: ActivityNotFoundException) { true }
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) { progress.visibility = View.VISIBLE }
            override fun onPageFinished(view: WebView, url: String?) { progress.visibility = View.GONE; swipe.isRefreshing = false; offline.visibility = View.GONE }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) { if (request.isForMainFrame) showOffline() }
        }
        web.webChromeClient = WebChromeClient()
        swipe.setOnRefreshListener { web.reload() }
        findViewById<View>(R.id.retry).setOnClickListener { loadHome() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })
        if (savedInstanceState == null) window.decorView.postDelayed({ loadHome() }, 900) else web.restoreState(savedInstanceState)
    }

    private fun loadHome() { if (isOnline()) web.loadUrl(homeUrl) else showOffline() }
    private fun showOffline() { progress.visibility = View.GONE; swipe.isRefreshing = false; offline.visibility = View.VISIBLE }
    private fun isOnline(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    override fun onDestroy() { web.stopLoading(); web.destroy(); super.onDestroy() }
}
